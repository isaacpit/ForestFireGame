﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour
{
    public Tree TreePrefab;
    public int TreeCount;
    private List<Tree> trees = new List<Tree>();
    public GameObject ObjectPool;
    public float fieldSize;
    // Start is called before the first frame update
    void Start()
    {
        bool exitForLoop = false;

        //Spawn Trees
        for (int i = 0; i < TreeCount; i++)
        {
            bool validSpot;
            float x, z;
            int loopCount = 0;

            //Look for open spot
            do
            {
                loopCount++;
                validSpot = true;
                x = Random.Range(-(fieldSize - .5f), (fieldSize - .5f));
                z = Random.Range(-(fieldSize - .5f), (fieldSize - .5f));

                //checks if spot is valid
                for (int j = 0; j < trees.Count; j++)
                {
                    if (Mathf.Abs(x - trees[j].transform.position.x) <= .25f || Mathf.Abs(z - trees[j].transform.position.z) <= .25f) {
                        Debug.Log(x + ", " + z + "blocked by " + trees[j].transform.position.x + ", " + trees[j].transform.position.z);
                        validSpot = false;
                    }
                }

                //Exit if stuck and can't find open spot
                if (loopCount >= 2000)
                {
                    exitForLoop = true;
                    validSpot = true;
                    Debug.Log("Maximum number of trees at: " + i);
                }
            } while (!validSpot);
            
            //create tree in new spot
            Tree newTree = Instantiate(TreePrefab, ObjectPool.transform);
            newTree.transform.position = new Vector3(x, 1.5f, z);
            trees.Add(newTree);
            if (exitForLoop) break;
            if (i == 0) newTree.FireState = 1;
        }

        //Create list of adjacent trees
        for (int i = 0; i < trees.Count; i++)
        {
            for (int j = 0; j < trees.Count; j++)
            {
                if (i != j && Vector3.Distance(trees[i].transform.position, trees[j].transform.position) <= 5.0f) trees[i].adjacentTrees.Add(trees[j]);
            }
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
